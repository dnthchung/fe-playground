import React from "react";
import Signup from "../AppComponents/signUp.tsx/Signup";

function page() {
  return (
    <div className="flex justify-center items-center h-screen poppins">
      <Signup />
    </div>
  );
}

export default page;
