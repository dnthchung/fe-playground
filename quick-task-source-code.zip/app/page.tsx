import SignIn from "./AppComponents/signIn/Signin";

export default function Home() {
  return (
    <div className="flex justify-center items-center h-screen poppins">
      <SignIn />
    </div>
  );
}
